					
INSERT INTO 	realise	(reacod, reanom, reapre)	VALUES	(	seq_realise.nextval, 'DeChauveron','Philippe');
INSERT INTO 	film	(filmcod,  catcod, reacod, filmtit, filman, filnat, filmdur)	VALUES	(	seq_film.nextval, 	null,	seq_realise.currval		,'Qu est-ce quon � fait au on dieu', 1800, 'F', null	);
INSERT INTO 	realise	(reacod, reanom, reapre)	VALUES	(	seq_realise.nextval, 'Bob','REINER');
INSERT INTO 	film	(filmcod,  catcod, reacod, filmtit, filman, filnat, filmdur)	VALUES	(	seq_film.nextval, 	null,	seq_realise.currval		,'Quand Harry rencontre Sally', 1800, 'F', null	);
INSERT INTO 	realise	(reacod, reanom, reapre)	VALUES	(	seq_realise.nextval, 'Xavier','GIANNOLI');
INSERT INTO 	film	(filmcod,  catcod, reacod, filmtit, filman, filnat, filmdur)	VALUES	(	seq_film.nextval, 	null,	seq_realise.currval		,'Quand j �tais Chanteur', 1800, 'F', null	);
INSERT INTO 	realise	(reacod, reanom, reapre)	VALUES	(	seq_realise.nextval, 'Gilles','PORTE');
INSERT INTO 	film	(filmcod,  catcod, reacod, filmtit, filman, filnat, filmdur)	VALUES	(	seq_film.nextval, 	null,	seq_realise.currval		,'uand la mer monte', 1800, 'F', null	);
INSERT INTO 	realise	(reacod, reanom, reapre)	VALUES	(	seq_realise.nextval, 'Christian','VINCENT');
INSERT INTO 	film	(filmcod,  catcod, reacod, filmtit, filman, filnat, filmdur)	VALUES	(	seq_film.nextval, 	null,	seq_realise.currval		,'Quatre �toiles', 1800, 'F', null	);
INSERT INTO 	realise	(reacod, reanom, reapre)	VALUES	(	seq_realise.nextval, 'Cristian','MUNGIU');
INSERT INTO 	film	(filmcod,  catcod, reacod, filmtit, filman, filnat, filmdur)	VALUES	(	seq_film.nextval, 	null,	seq_realise.currval		,'Quatre mois, 3 semaines et 2jours', 1800, 'F', null	);
INSERT INTO 	film	(filmcod,  catcod, reacod, filmtit, filman, filnat, filmdur)	VALUES	(	seq_film.nextval, 	null,	seq_realise.currval		,'Quatre mois, 3 semaines, 2 jours', 1800, 'F', null	);
INSERT INTO 	realise	(reacod, reanom, reapre)	VALUES	(	seq_realise.nextval, 'Patrick','TIMSIT');
INSERT INTO 	film	(filmcod,  catcod, reacod, filmtit, filman, filnat, filmdur)	VALUES	(	seq_film.nextval, 	null,	seq_realise.currval		,'Quelqu un de bien', 1800, 'F', null	);
INSERT INTO 	realise	(reacod, reanom, reapre)	VALUES	(	seq_realise.nextval, 'Santiago','AMIGORENA');
INSERT INTO 	film	(filmcod,  catcod, reacod, filmtit, filman, filnat, filmdur)	VALUES	(	seq_film.nextval, 	null,	seq_realise.currval		,'Quelques jours en Septembre', 1800, 'F', null	);
INSERT INTO 	realise	(reacod, reanom, reapre)	VALUES	(	seq_realise.nextval, 'Gilles','MARCHAND');
INSERT INTO 	film	(filmcod,  catcod, reacod, filmtit, filman, filnat, filmdur)	VALUES	(	seq_film.nextval, 	null,	seq_realise.currval		,'Qui � tu� Bambi ?', 1800, 'F', null	);
INSERT INTO 	realise	(reacod, reanom, reapre)	VALUES	(	seq_realise.nextval, 'Robert','ZEMECKIS');
INSERT INTO 	film	(filmcod,  catcod, reacod, filmtit, filman, filnat, filmdur)	VALUES	(	seq_film.nextval, 	null,	seq_realise.currval		,'Qui veut la peau de Roger Rabbit', 1800, 'F', null	);

commit;
												
